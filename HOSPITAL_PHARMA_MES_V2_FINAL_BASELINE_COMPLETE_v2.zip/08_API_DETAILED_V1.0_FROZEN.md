# 06 API接口详细设计说明书 V1.0 FROZEN

## 全局契约
Base `/api/v1`；JWT Bearer。写请求必须有 `Idempotency-Key`（创建/业务动作）；更新必须有 `If-Match` 或 `versionNo`。
统一错误：`requestId, code, message, fieldErrors[], allowedActions[]`。
HTTP：400格式；401未认证；403无权限；404不存在；409状态/并发/重复；422领域规则；500未知。
业务写入与AuditEvent同事务；外部事件经Outbox。

## DTO通则
ID使用string/long一致策略；Quantity使用decimal字符串或BigDecimal；时间ISO-8601；枚举只接受OpenAPI列举值。客户端不得传createdBy/updatedBy/audit actor/最终服务器时间。

## 核心接口
### POST /materials
Permission `master:material:create`。Request MaterialCreateRequest：materialCode/name/type/baseUnitId及PRD MD-MAT-001字段。Validation：编码唯一、单位存在、类型合法。Response MaterialResponse。201。事务：Material+Audit。
### POST /process-packages/{id}/versions/{versionId}/approve
Permission `process:package:approve`。要求SUBMITTED、lint pass、审批人职责分离。200 ProcessPackageVersionResponse；409 INVALID_STATE；422 LINT_FAILED。副作用：contentHash、Audit、Signature(若策略要求)。
### POST /main-batches
Permission `production:batch:create`。Request productionOrderId/productId/plannedQty/unitId/subBatchPlan(optional)。201 MainBatchResponse。
### POST /main-batches/{id}/release
Permission `production:batch:release`；Idempotency-Key必需；If-Match必需。Gate：定义APPROVED/EFFECTIVE、快照可生成。副作用：ProcessSnapshot、ExecutionUnits、Audit。422 BATCH_DEFINITION_NOT_READY。
### POST /operations/{id}/start
Permission `mes:operation:start`。Gate：READY、qualification、equipment、clearance、material prerequisites。200 OperationResponse；409 INVALID_OPERATION_STATE；422 PRECONDITION_FAILED。
### POST /weighings
Permission `mes:weigh:create`。Request executionUnitId/materialLotId/formulaItemId/targetQty/actualQty/unitId/scaleEquipmentId。Gate：lot RELEASED、BOM match、scale valid、qualification、tolerance。201 WeighingResponse。
### POST /weighings/{id}/verify
Permission `mes:weigh:verify`。Gate：independent verifier when required。200；422 SELF_VERIFICATION_FORBIDDEN。
### POST /material-charges
Permission `mes:charge:create`。Request executionUnitId/operationExecutionId/materialLotId/weighingRecordId/chargedQty/unitId。Gate：operation IN_PROGRESS、lot RELEASED、BOM match、quantity、verification。副作用同事务：MaterialCharge + QuantityEvent(CHARGE)+InventoryLedger(CONSUME)+Genealogy+Audit。201。422 MATERIAL_NOT_RELEASED/MATERIAL_NOT_IN_BOM/CHARGE_QTY_INVALID。
### PUT /forms/{id}/draft-values
Permission `ebr:form:edit`。If-Match=formRevision。Request values[{fieldCode,occurrencePath,value,unitId,sourceRef}]。服务端执行ON_CHANGE/ON_SAVE规则。409 REVISION_CONFLICT。
### POST /forms/{id}/submit
Permission `ebr:form:submit`。执行ON_SUBMIT rules；BLOCK失败422 EBR_RULE_BLOCKED。成功生成RuleExecution/Audit。
### POST /field-values/{id}/corrections
Permission `ebr:record:correct`。Request newValue,reason。追加Revision；失效受影响Review/Signature。200 CorrectionResponse。
### POST /records/{type}/{id}/sign
Permission `ebr:sign`。Request meaning,reauthCredential/token。服务端计算recordDigest。401 REAUTH_FAILED；409 RECORD_CHANGED。
### GET /main-batches/{id}/material-balance
Permission `balance:view`。从QuantityEvent计算/读取最新计算版本，不接受客户端汇总。
### POST /balances/{id}/investigations
Permission `balance:investigate`。创建调查；批准接口需`balance:approve`。
### POST /release-decisions
Permission `qa:release`。Request mainBatchId,decision,reason,signatureContext。Gate：MainBatch PENDING_QA；eBR/QC/Balance/Deviation/Signature PASS。副作用：immutable ReleaseDecision + Finished MaterialLot availability + Audit/Outbox。422 RELEASE_GATE_FAILED。

## 审计要求
所有状态转换、批准、签名、更正、库存调整、称量/投料、质量结果修订、Release均产生AuditEvent。GET默认不产生GxP Audit，敏感导出可产生AccessAudit。
