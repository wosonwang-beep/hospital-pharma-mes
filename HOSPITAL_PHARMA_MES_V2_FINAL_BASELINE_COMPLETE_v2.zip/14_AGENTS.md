# hospital-pharma-mes — FINAL FROZEN Engineering Rules
This directory is the sole authoritative development baseline.

Priority on conflict:
1. 01 PRD Requirement
2. 04 Domain Detailed Design / Frozen invariants
3. 05 Database Design
4. 06 eBR Detailed Design
5. 07 State Machine
6. 08 API + OpenAPI
7. 09 Functional Detailed Design
8. 10 UI Detailed Design V1.1
9. 11 GMP/Audit/eSignature
10. 12 Test Acceptance
11. 13 RTM
12. Current MES-XXX-R2 task

Codex is an implementation agent, not product architect.
Never invent requirements, fields, states, permissions, GMP rules, routes or APIs.
If specification is missing or contradictory: STOP and report MISSING SPECIFICATION / DESIGN CONFLICT.
Do not modify frozen design as part of implementation.
Do not refactor unrelated modules.
One MES task at a time. When acceptance + affected regression pass: STOP.
UI rule: Query/List, Create, View and Edit are separate routes/pages. Do not replace them with CRUD modals/drawers.
