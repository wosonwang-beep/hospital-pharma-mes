# 系统架构设计说明书

模块化单体：iam/masterdata/process/production/wms/execution/qms/release/audit/integration/reporting。业务写入与审计同事务；集成使用outbox；受控定义发布后不可原地修改；写接口幂等+乐观锁。
