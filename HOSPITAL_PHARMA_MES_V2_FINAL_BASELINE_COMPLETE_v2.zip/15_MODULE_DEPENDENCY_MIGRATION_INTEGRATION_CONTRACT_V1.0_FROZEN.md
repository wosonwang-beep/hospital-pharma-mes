# 15 医院制剂 MES V2.0 模块依赖、数据库 Migration 顺序与 Integration Contract Matrix V1.0 FROZEN

## 1. 核心施工原则
- **整体设计一次冻结，按依赖增量实现。** Task是施工增量，不是孤立模块。
- Hard Dependency未验收，后续Task不得正式施工；Soft Dependency只要求契约已冻结，可延迟实现。
- 表的业务归属不决定Migration时点；跨模块表在所有FK依赖存在后创建。
- 每个Task区分 Primary Write Scope 与 Read/Integration Scope。
- GPT-5.6生成Implementation Plan前必须执行Dependency Check + Impact Analysis。
- Codex不得为解决尚未实现的依赖创建临时业务表/临时字段/替代模型。

## 2. Task Dependency Matrix
|Task|Capability|Hard Dependency|Soft Dependency|Produces Contract For|Primary Contract|
|---|---|---|---|---|---|
|MES-001-R2|平台/Audit/Integration|—|—|MES-002..013|Migration/Audit/Outbox基础|
|MES-002-R2|RBAC|MES-001|—|MES-003..013|Identity/Permission Contract|
|MES-003-R2|组织/单位/设备/资格|MES-001,MES-002|—|MES-004,006,008,009,010,011|Org/UOM/Equipment/Qualification|
|MES-004-R2|物料|MES-001,MES-003|MES-005|MES-006,008,011,012|Material/MaterialVersion|
|MES-005-R2|供应商|MES-001,MES-003,MES-004|—|MES-008|Approved Supplier|
|MES-006-R2|产品/BOM/工艺|MES-003,MES-004|MES-007|MES-007,009,010,011,012|ProcessSnapshot inputs/BOM/Route|
|MES-007-R2|eBR引擎|MES-001,MES-002,MES-006|MES-009|MES-009,010,012,013|eBR Definition/Runtime Contract|
|MES-008-R2|WMS|MES-003,MES-004,MES-005|MES-009|MES-011,012|MaterialLot/InventoryLedger|
|MES-009-R2|订单/正式批|MES-003,MES-004,MES-006,MES-007|MES-008|MES-010,011,012,013|MainBatch/ProcessSnapshot/ExecutionUnit|
|MES-010-R2|工序/设备/参数|MES-003,MES-006,MES-007,MES-009|MES-008|MES-011,012,013|OperationExecution/EquipmentRun|
|MES-011-R2|称量/投料/追溯|MES-004,MES-006,MES-008,MES-009,MES-010|MES-007|MES-012,013|MaterialCharge/QuantityEvent/Genealogy|
|MES-012-R2|IPC/QMS/平衡|MES-009,MES-010,MES-011|MES-007|MES-013|QC/Deviation/Balance evidence|
|MES-013-R2|QA Release/归档|MES-007,MES-009,MES-011,MES-012|—|—|ReleaseDecision/Final eBR|

## 3. 推荐施工拓扑
主顺序保持 MES-001 → 002 → 003 → 004 → 005 → 006 → 007 → 008 → 009 → 010 → 011 → 012 → 013。
但每次开工必须重新检查Hard Dependencies；MES-008/009、MES-007/009/010存在跨模块物理表延迟创建，按Migration图执行。

## 4. Database Migration Dependency
|Migration|Task|Name|Tables/Capability|Depends On|
|---|---|---|---|---|
|V001|MES-001|platform_base|公共审计列规范、gxp_audit_event、gxp_signature、integration_inbox/outbox|无|
|V002|MES-002|iam_rbac|sys_user,sys_role,sys_permission,sys_menu及关系表|V001|
|V003|MES-003|organization_uom_equipment|md_organization,md_unit,md_unit_conversion,md_equipment,md_qualification|V001,V002|
|V004|MES-004|material_master|md_material,md_material_version,quality/storage/production rules|V003|
|V005|MES-005|supplier|md_supplier,md_material_supplier|V004|
|V006|MES-006|process_bom_route|md_product,proc_package/version,formula/item,route,operation,param|V003,V004|
|V007A|MES-007|ebr_definition|ebr_template/section/group/form/field/option/rule/signature_rule/review_rule|V006|
|V008A|MES-008|wms_core|wms_warehouse,location,container,material_lot,inventory_ledger|V003,V004,V005|
|V009A|MES-009|production_core|prd_production_order,prd_process_snapshot,prd_main_batch,prd_sub_batch,prd_execution_unit|V006,V007A|
|V009B|MES-009|cross_wms_batch|wms_reservation,wms_material_issue,wms_material_issue_item|V008A,V009A|
|V009C|MES-009|ebr_batch_runtime_root|ebr_batch_snapshot|V007A,V009A|
|V010|MES-010|execution|mes_operation_execution,mes_equipment_usage,mes_equipment_run,mes_parameter_value|V003,V006,V009A|
|V007B|MES-010|ebr_runtime_forms|ebr_form_instance,ebr_field_value_revision,ebr_rule_execution,ebr_review_record,ebr_attachment|V007A,V009C,V010|
|V011|MES-011|weigh_charge_genealogy|mes_weighing_record,mes_material_charge,mes_quantity_event,mes_genealogy|V004,V006,V008A,V009A,V010|
|V012|MES-012|qms_balance|qms_ipc_instance,qms_sample,qms_test_result_revision,qms_deviation,qms_capa,mes_balance_rule/result/investigation|V009A,V010,V011|
|V013|MES-013|release_archive|qms_release_decision,ebr_pdf_manifest及最终归档索引/约束|V007B,V009A,V011,V012|

### 4.1 跨模块延迟建表规则
`wms_reservation`、`wms_material_issue*` 业务归属WMS，但依赖MainBatch，因此在V009B创建。
`ebr_batch_snapshot` 业务归属eBR，但依赖MainBatch，因此在V009C创建。
`ebr_form_instance`等运行表依赖OperationExecution，因此Definition在V007A创建，Runtime在V007B（物理执行时排在V010之后）创建。
Flyway真实版本号必须保持单调递增；上述A/B标识是逻辑分组，落地时应转换为实际连续版本号（例如V007,V008...），禁止执行后改写旧Migration。

## 5. Integration Contract Matrix
|Producer|Contract|Consumer|Source of Truth|Transaction/Event|Failure Behavior|Regression Scope|
|---|---|---|---|---|---|---|
|Material|MaterialVersion|Process/BOM; WMS; Weighing|md_material + md_material_version|同步读取|版本不可变|物料版本变更不影响历史批|
|Supplier|ApprovedSupplier|WMS Receipt|md_material_supplier|同步读取|过期/未批准422|收货资格|
|Process|FormulaItem/BOM|WMS; Weighing; Charge|proc_formula_item + ProcessSnapshot|批次冻结|BOM mismatch 422|物料用量/匹配|
|Process|Route/OperationDef|Execution|proc_operation_def snapshot|批次冻结|定义未批准阻断Release|工序执行|
|eBR Definition|Published Template|MainBatch/eBR Runtime|ebr_template_version|Snapshot|未批准阻断Batch Release|运行批稳定性|
|MainBatch|ProcessSnapshot|Execution/eBR/Balance/Release|prd_process_snapshot|同Release事务|快照失败整批Release回滚|批次定义真源|
|MainBatch|Execution Context|Operation/WMS/Charge/QMS|prd_main_batch + prd_execution_unit|同步|非法状态409|跨模块批次上下文|
|WMS|MaterialLot|Weighing/Charge/QC|wms_material_lot|同步|非RELEASED/过期/冻结422|物料资格|
|WMS|InventoryLedger|Balance/Inventory Query|wms_inventory_ledger|本地事务|重复key幂等|库存事实账|
|Weighing|WeighingRecord|MaterialCharge/eBR|mes_weighing_record|同步|未确认/未复核阻断Charge|称量证据|
|MaterialCharge|Actual Charge|Inventory/Balance/Genealogy/eBR|mes_material_charge|单本地事务|任一副作用失败全回滚|实际投料真源|
|MaterialCharge|QuantityEvent(CHARGE)|MaterialBalance|mes_quantity_event|同Charge事务|禁止缺sourceRef|平衡输入|
|MaterialCharge|Genealogy Edge|Traceability/Release|mes_genealogy|同Charge事务|缺链路视数据完整性异常|正反向追溯|
|Operation|OperationExecution|eBR/IPC/Balance|mes_operation_execution|同步|Gate失败BLOCKED|执行状态|
|QC|TestResult Evidence|QA Release|qms_test_result_revision|同步读取|QC PASS不触发Release|质量证据|
|Deviation|Deviation Status|Operation/QA Release|qms_deviation|同步读取|关键开放偏差阻断|异常Gate|
|Balance|BalanceResult|Batch Complete/QA Release|mes_balance_result|同步读取|FAIL未批准阻断|平衡Gate|
|eBR Runtime|Record Completeness/Signatures|QA Release|ebr runtime + gxp_signature|同步读取|缺失/失效签名阻断|批记录证据|
|QA Release|ReleaseDecision|Finished Inventory/ERP|qms_release_decision|本地事务+Outbox|Gate变化409/422|正式放行真源|

## 6. Task执行模板
每个MES-XXX Implementation Plan必须新增以下章节：
1. Dependency Check：Hard Dependency版本/验收状态。
2. Primary Write Scope：本Task允许修改的表/服务/API/UI。
3. Read/Integration Scope：必须读取但原则上不修改的上游/下游。
4. Contracts Consumed：消费哪些Contract及版本。
5. Contracts Produced：本Task向后续提供什么。
6. Migration Plan：按FK/UK/Index依赖排序。
7. Impact Analysis：受影响Requirement/API/UI/Test。
8. Integration Tests：至少覆盖每个跨模块Contract正常+失败路径。
9. Regression Scope：上游已验收能力哪些必须重跑。

## 7. 关键跨模块事务
MaterialCharge确认必须保证 Charge + QuantityEvent + InventoryLedger(CONSUME) + Genealogy + Audit 原子一致；外部通知走Outbox。
MainBatch Release必须保证ProcessSnapshot/ExecutionUnit/eBR Batch Snapshot等批次启动证据一致；失败不得留下半批次。
QA Release必须重新读取eBR/QC/Deviation/Balance/Signature Gate；Decision与库存可用状态/Outbox按设计保证一致。

## 8. 禁止事项
禁止因后续模块未实现而弱化FK语义；禁止创建temporary_batch/temp_material等替代业务模型；禁止提前实现后续Task的完整业务；禁止只跑本模块Unit Test而不跑Contract Integration Test；禁止修改已执行Migration。