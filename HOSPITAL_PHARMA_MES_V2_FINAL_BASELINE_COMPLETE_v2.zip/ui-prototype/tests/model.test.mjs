import test from 'node:test';
import assert from 'node:assert/strict';
import { scenarios, materialRoutes, canPerform, resolveScenario } from '../prototype/model.mjs';

test('freezes exactly thirteen uniquely routed MES core scenarios', () => {
  assert.equal(scenarios.length, 13);
  assert.equal(new Set(scenarios.map((item) => item.id)).size, 13);
  assert.equal(new Set(scenarios.map((item) => item.route)).size, 13);
  assert.deepEqual(scenarios.map((item) => item.task), Array.from({ length: 13 }, (_, index) => `MES-${String(index + 1).padStart(3, '0')}-R2`));
});

test('material query create view and edit use separate routes and surface modes', () => {
  assert.deepEqual(materialRoutes, {
    query: '/master/materials',
    create: '/master/materials/create',
    view: '/master/materials/MAT-00028',
    edit: '/master/materials/MAT-00028/edit',
  });
  assert.equal(resolveScenario(materialRoutes.query).mode, 'query');
  assert.equal(resolveScenario(materialRoutes.create).mode, 'create');
  assert.equal(resolveScenario(materialRoutes.view).mode, 'view');
  assert.equal(resolveScenario(materialRoutes.edit).mode, 'edit');
});

test('actions require both permission and server allowedActions membership', () => {
  const context = { permissions: ['production:batch:start'], allowedActions: ['START', 'PAUSE'] };
  assert.equal(canPerform(context, 'production:batch:start', 'START'), true);
  assert.equal(canPerform(context, 'production:batch:complete', 'COMPLETE'), false);
  assert.equal(canPerform(context, 'production:batch:start', 'RELEASE'), false);
});

test('every frozen scenario declares traceability and a png screenshot', () => {
  for (const scenario of scenarios) {
    assert.match(scenario.requirement, /[A-Z]+(?:-[A-Z]+)*-\d{3}|PLAT-001|IAM-001/);
    assert.match(scenario.permission, /^[a-z]+:[a-z-]+(?::[a-z-]+)?$/);
    assert.match(scenario.api, /^(GET|POST|PUT) \/.+/);
    assert.match(scenario.screenshot, /^UI-[A-Z0-9-]+\.png$/);
  }
});
